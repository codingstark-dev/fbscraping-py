from tkinter import *
root = Tk()
root.geometry("200x200") 
scrollbar = Scrollbar(root)
scrollbar.pack(sid=RIGHT, fill=Y)
mylist = Listbox(root, yscrollcommand=scrollbar.set)
for line in range(100):
    mylist.insert(END, ' Hey There ' + str(line))
mylist.pack(side=LEFT, fill=BOTH)

scrollbar.config(command=mylist.yview)

root.mainloop()
